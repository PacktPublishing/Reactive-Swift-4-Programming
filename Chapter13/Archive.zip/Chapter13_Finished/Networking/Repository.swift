
import Foundation

struct Repository {
    
    let repoName: String
    let repoURL: String
}
