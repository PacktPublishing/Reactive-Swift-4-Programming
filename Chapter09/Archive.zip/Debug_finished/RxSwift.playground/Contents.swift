//: Please build the scheme 'RxSwiftPlayground' first

import RxSwift
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

func exampleWithPublish(){
    let intervalSeq = Observable<Int>.interval(1, scheduler: MainScheduler.instance)
    .publish()

    intervalSeq
        .debug("First")
        .subscribe { _ in }

    delayInExecution(2) {
        _ = intervalSeq.connect()
    }

    delayInExecution(4) {
        intervalSeq
            .debug("Second")
            .subscribe { _ in }
            .dispose()
    }
}

exampleWithPublish()

