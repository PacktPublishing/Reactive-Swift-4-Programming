// Please build the scheme 'RxSwiftPlayground' first

import RxSwift
exampleOf(description: "total") {
    print(RxSwift.Resources.total)
    
    let object = NSObject()
    var disposeBag = DisposeBag()
    print(RxSwift.Resources.total)
    
    let stringSequence = Observable.just("I am a string")
    print(RxSwift.Resources.total)
    
    stringSequence
        .subscribe(onNext: { _ in
            print(RxSwift.Resources.total)
        })
        .disposed(by: disposeBag)
    
    disposeBag = DisposeBag()
    print(RxSwift.Resources.total)
}
print(RxSwift.Resources.total)


