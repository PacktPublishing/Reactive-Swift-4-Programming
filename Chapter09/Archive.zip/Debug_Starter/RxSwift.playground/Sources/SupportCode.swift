import Foundation

public func exampleOf(description: String, actionToPerform: () -> Void) {
    print(" ===> Example of:", description, "===>")
    actionToPerform()
}

public func delayInExecution(_ delayInterval: TimeInterval, actionToPerform: @escaping () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: .now() + delayInterval) {
        actionToPerform()
    }
}

