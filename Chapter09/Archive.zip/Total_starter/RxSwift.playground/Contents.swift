// Please build the scheme 'RxSwiftPlayground' first

import RxSwift

exampleOf(description: "total") {
    
}


