
import UIKit

class Header: UICollectionReusableView {
    
    @IBOutlet weak var titleLabel: UILabel!
}
