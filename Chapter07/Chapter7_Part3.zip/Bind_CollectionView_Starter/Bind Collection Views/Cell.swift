
import UIKit

class Cell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
}
