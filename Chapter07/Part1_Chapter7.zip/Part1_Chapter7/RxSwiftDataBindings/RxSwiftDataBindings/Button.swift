//
//  Button.swift
//  RxSwiftDataBindings
//
//  Created by Mac Mini on 19/11/17.
//  Copyright © 2017 Mac Mini. All rights reserved.
//

import UIKit

class Button: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        configure()
    }
    
    func configure() {
        layer.cornerRadius = 5.0
    }
}
