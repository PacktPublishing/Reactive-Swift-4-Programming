//
//  ViewController.swift
//  RxSwiftDataBindings
//
//  Created by Mac Mini on 19/11/17.
//  Copyright © 2017 Mac Mini. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {
    
    @IBOutlet weak var demoTapGestureRecognizer: UITapGestureRecognizer!
    @IBOutlet weak var demoTextField: UITextField!
    @IBOutlet weak var demoButton: Button!
    
    let disposeBag = DisposeBag()
    let demoTextFieldText = Variable("")
    let buttonTapped = PublishSubject<String>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

