//
//  AppDelegate.swift
//  Mother_Earth
//
//  Created by Sonar on 24/10/17.
//  Copyright © 2017 Navdeep. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

}

