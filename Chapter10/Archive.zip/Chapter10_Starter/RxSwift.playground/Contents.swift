// Please build the scheme 'RxSwiftPlayground' first
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

import RxSwift

let imageView = UIImageView(
    frame: CGRect(
        x: 0,
        y: 0,
        width: 128,
        height: 128
    )
)

PlaygroundPage.current.liveView = imageView

let swift = UIImage(named: "Swift")!

let swiftImageData = UIImagePNGRepresentation(swift)!

let rx = UIImage(named: "Rx")!

let rxImageData = UIImagePNGRepresentation(rx)!

let disposeBag = DisposeBag()

