

import XCTest
import RxSwift
import RxTest
import RxBlocking

class TestingTests: XCTestCase {
    
    var scheduler: TestScheduler!
    var subscription: Disposable!
    
    override func setUp() {
        super.setUp()
        
        scheduler = TestScheduler(initialClock: 0)
    }
    
    override func tearDown() {
        scheduler.scheduleAt(1000) {
            self.subscription.dispose()
        }
        
        super.tearDown()
    }
    
    func testMapOperator(){
        let localObserver = scheduler.createObserver(Int.self)
        let observableSeq = scheduler.createHotObservable([
            next(100,10),
            next(200,20),
            next(300,30)
            ])
        
        let observableForMap = observableSeq.map {$0 * 2}
        scheduler.scheduleAt(0){
            self.subscription = observableForMap.subscribe(localObserver)
        }
        scheduler.start()
        
        let restultsFromMapOperation = localObserver.events.map{
            $0.value.element!
        }
        
        XCTAssertEqual(restultsFromMapOperation, [20,40,60])
    }
    
    func testMapOperatorCold(){
        let disposeBag = DisposeBag()
        
        let firstObserver = scheduler.createObserver(Int.self)
        let secondObserver = scheduler.createObserver(Int.self)
        
        let observableSeq = scheduler.createColdObservable([
            next(100,10),
            next(200,20),
            next(300,30)
            ])
        
        let firstObservableForMap = observableSeq.map {$0 * 2}
        let secondObservableForMap = observableSeq.map {$0 * 4}
        scheduler.scheduleAt(0){
            firstObservableForMap.subscribe(firstObserver).disposed(by: disposeBag)
        }
        scheduler.scheduleAt(150){
            secondObservableForMap.subscribe(secondObserver).disposed(by: disposeBag)
        }
        scheduler.start()
        
        var restultsFromMapOperation = firstObserver.events.map{
            $0.value.element!
        }
        
        _ = secondObserver.events.map{
            restultsFromMapOperation.append($0.value.element!)
        }
        
        XCTAssertEqual(restultsFromMapOperation, [20, 40, 60, 40, 80, 120])
    }
    
    func testMapOperatorHot(){
        let disposeBag = DisposeBag()
        
        let firstObserver = scheduler.createObserver(Int.self)
        let secondObserver = scheduler.createObserver(Int.self)
        
        let observableSeq = scheduler.createHotObservable([
            next(100,10),
            next(200,20),
            next(300,30)
            ])
        
        let firstObservableForMap = observableSeq.map {$0 * 2}
        let secondObservableForMap = observableSeq.map {$0 * 4}
        scheduler.scheduleAt(0){
            firstObservableForMap.subscribe(firstObserver).disposed(by: disposeBag)
        }
        scheduler.scheduleAt(150){
            secondObservableForMap.subscribe(secondObserver).disposed(by: disposeBag)
        }
        scheduler.start()
        
        var restultsFromMapOperation = firstObserver.events.map{
            $0.value.element!
        }
        
        _ = secondObserver.events.map{
            restultsFromMapOperation.append($0.value.element!)
        }
        
        XCTAssertEqual(restultsFromMapOperation, [20, 40, 60, 80, 120])
    }
    
    func testBlocking(){
        let observableToTest = Observable.of(10, 20, 30)
//        do{
//            let result = try observableToTest.toBlocking().first()
//            XCTAssertEqual(result, 10)
//        } catch {
//            XCTFail(error.localizedDescription)
//        }
        XCTAssertEqual(try! observableToTest.toBlocking().first(), 10)
    }
    
    func testAsynchronousToArry(){
        let scheduler = ConcurrentDispatchQueueScheduler(qos: .background)
        
        let intObservbale = Observable.of(10, 20, 30)
            .map{ $0 * 2 }
            .subscribeOn(scheduler)
        
        print("------")
        
        subscription = intObservbale.subscribe{ print($0) }
        do{
            let result = try intObservbale.observeOn(MainScheduler.instance).toBlocking().toArray()
            XCTAssertEqual(result, [20, 40, 60])
        } catch {
            XCTFail(error.localizedDescription)
        }
    }
}
